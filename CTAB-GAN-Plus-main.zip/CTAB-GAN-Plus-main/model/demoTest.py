from ctabgan import CTABGAN
# from eval.evaluation import get_utility_metrics, stat_sim, privacy_metrics
import numpy as np
import pandas as pd
import glob

num_exp = 1
dataset = "A-0.1X"
real_path = "E:/pythonProject/CTAB-GAN-Plus-main/Real_Datasets/A-0.1X.csv"
#fake_file_root = "E:/pythonProject/CTAB-GAN-Plus-main/Fake_Datasets"

synthesizer = CTABGAN(raw_csv_path=real_path,
                      test_ratio=0.20,
                      categorical_columns=['course', 'gender', 'age_band', 'region', 'highest_education', 'imd_band',
                                           'disability'],
                      log_columns=[],
                      mixed_columns={},
                      general_columns=[],
                      non_categorical_columns=[],
                      integer_columns=['sum_click', 'studied_credits', 'Attitude', 'num_of_prev_attempts', 'RegisterDuration'],
                      problem_type={"Classification": 'final_result'})
for i in range(num_exp):
    synthesizer.fit()
    syn = synthesizer.generate_samples()
    syn.to_csv("E:/pythonProject/CTAB-GAN-Plus-main/Fake_Datasets/A-0.1X.csv")
    #syn.to_csv(fake_file_root + "/" + dataset + "/" + dataset + "_fake_{exp}.csv".format(exp=i), index=False)
