import pandas as pd
import os
import random
import scipy.stats
import numpy as np
from scipy.stats import wasserstein_distance
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import eli5
from eli5.sklearn import PermutationImportance
from sklearn import preprocessing
from scipy.stats import norm
from scipy import stats

path = 'E:/科研/成果维护/SCI/semi-supervised and self-training method for early success prediction/fake data/fake-all/'
files = os.listdir(path)
for file in files:
    f = pd.read_csv(path + file)
    for i in (0.1, 0.5, 1, 3, 5):
        sampleID = random.sample(range(0, len(f)), int((i / 9.6) * len(f)))
        f.iloc[sampleID].to_csv(path + "/" + file[0] + "-" + str(i) + ".csv", index=False)

# JS divergence calculation
A1 = pd.read_csv(
    "E:/科研/成果维护/SCI/semi-supervised and self-training method for early success prediction/six courses/AAA/A-0.1X.csv")
A2 = pd.read_csv(
    "E:/科研/成果维护/SCI/semi-supervised and self-training method for early success prediction/fake data/AAA/A-0.1.csv")

p = np.asarray(A1.iloc[:, -1])
q = np.asarray(A2.iloc[:, -1])


def JS_divergence(p, q):
    M = (p + q) / 2
    return 0.5 * scipy.stats.entropy(p, M, base=2) + 0.5 * scipy.stats.entropy(q, M, base=2)


JS_divergence(p, q)

wasserstein_distance(p, q)

path1 = 'E:/科研/成果维护/SCI/semi-supervised and self-training method for early success prediction/fake data/FFF/'
path2 = 'E:/科研/成果维护/SCI/semi-supervised and self-training method for early success prediction/six courses/FFF/'
files1 = os.listdir(path1)
files2 = os.listdir(path2)
for i in range(5):
    A1 = pd.read_csv(path1 + files1[i])
    A2 = pd.read_csv(path2 + files2[i])
    p = np.asarray(A1.iloc[:, -1])
    q = np.asarray(A2.iloc[:, -1])
    print("JS-divergence is " + str(JS_divergence(p, q)))
    print("WD is " + str(wasserstein_distance(p, q)))

sns.set(context='notebook', font='time new roman', style='whitegrid')
s = pd.Series(p)
plt.figure(figsize=(8, 4))
sns.displot(s, bins=5, rug=True, label='performance')
plt.legend()  # 创建图例
plt.grid(linestyle='--')
plt.show()

data1 = pd.read_csv(
    'E:/科研/成果维护/SCI/semi-supervised and self-training method for early success prediction/x is fake.csv')
data2 = pd.read_csv(
    'E:/科研/成果维护/SCI/semi-supervised and self-training method for early success prediction/x is real.csv')

# 绘制一个变量的直方图和概率密度图
s1 = pd.read_csv(
    'E:/科研/成果维护/SCI/semi-supervised and self-training method for early success prediction/fake data/real-Courses-all.csv')
plt.figure(figsize=(8, 4))
sns.displot(data=s1, x="final_result", kind="kde", hue="course")  # 根据course分类，画出的概率密度图
plt.show()

s2 = pd.read_csv(
    'E:/科研/成果维护/SCI/semi-supervised and self-training method for early success prediction/fake data/fake_courses-all.csv')
sns.displot(data=s2, x='final_result', kind='kde', hue="course")
plt.show()

dataImport = pd.read_csv('E:/科研/成果维护/SCI/semi-supervised and self-training method for early success prediction/fake '
                         'data/real-Courses-all.csv')
y = dataImport['final_result']
x = dataImport.drop(['final_result'], axis=1)
# label encoder for x
for i in ['course', 'gender', 'age_band', 'disability', 'region', 'imd_band', 'highest_education']:
    enc = preprocessing.LabelEncoder()
    enc = enc.fit(x[i])
    x[i] = enc.transform(x[i])
D = pd.concat([x, y], axis=1)
train_x, val_x, train_y, val_y = train_test_split(x, y, random_state=1)
my_model = RandomForestClassifier().fit(train_x, train_y)

perm = PermutationImportance(my_model, random_state=1).fit(val_x, val_y)
eli5.show_weights(perm, feature_names=val_x.columns.tolist())

sns.set(style="white", font_scale=1.5)
g = sns.jointplot(x='score', y='final_result', data=dataImport, color='#098154', kind='kde', )
g.fig.set_size_inches(10, 8)
# the barplot of courses
p3 = sns.countplot(data=D, x='course', hue='final_result', palette='Blues', linewidth=1, edgecolor='black')
p3.set_xticklabels(['AAA', 'BBB', 'CCC', 'DDD', 'EEE', 'FFF'])
p3.legend(labels=['Distinction', 'Pass', 'Fail', 'Withdrawn'], title='FinalResult')

p4 = sns.countplot(data=D, x='highest_education', hue='final_result', palette='Blues', linewidth=1, edgecolor='black')
p4.set_xticklabels(['A Level or Equivalent', 'HE Qualification', 'Lower Than A Level', 'No Formal quals',
                    'Post Graduate Qualification'],rotation=15,fontsize=7)
p4.legend(labels=['Distinction', 'Pass', 'Fail', 'Withdrawn'], title='FinalResult')
plt.show()

p5 = sns.countplot(data=D, x='imd_band', hue='final_result', palette='Greens', linewidth=1, edgecolor='black')
p5.set_xticklabels(['empty', '0-10%', '10-20%', '20-30%', '30-40%', '40-50%', '50-60%', '60-70%', '70-80%', '80-90%', '90-100%'
                    ],rotation=15,fontsize=7)
p5.legend(labels=['Distinction', 'Pass', 'Fail', 'Withdrawn'], title='FinalResult')
plt.savefig('E:/科研/成果维护/SCI/semi-supervised and self-training method for early success prediction/fake data/test5.jpg', dpi=600)
plt.show()